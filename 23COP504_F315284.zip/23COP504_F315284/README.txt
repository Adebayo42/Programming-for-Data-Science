# Student Monitoring System Documentation

This Student Monitoring System is a Python application designed to assist Module Leaders in tracking student engagement and performance in formative and summative online tests. The system includes a GUI (Graphical User Interface) with several functionalities accessible through buttons.

## Functions

### 1. Load and Clean Data
**Button**: Load and Clean Data  
**Function**: clean_data()`

This function reads CSV files, cleans, and returns a dataframe. Use this to load data into the system.

### 2. Retrieve Student Test Results
**Button**: Display Student Test Results  
**Function**: `test_result(research_id)`

Enter a student ID, click submit, and the system will display the test results for that specific student.

### 3. Student Performance
**Button**: Display Student Performance  
**Function**: `student_performance(research_id, test_name)`

Input student ID and test name, then click submit to display the student's absolute and relative test performance.

### 4. Underperforming Students
**Button**: Display Underperforming Students  
**Function**: `underperforming()`
## A student is classified as 'underperforming' if they score below 50 both in their summative online test and their Formative Mock Test

Click this button to identify underperforming students based on predefined criteria.

### 5. Display Hardworking Students
**Button**: Hardworking Students  
**Function**: `hardworking()`
## A student is classified as 'hardworking' if their summative online test score exceeds 60, and their self-ratings is categorised as either “Below Beginner” or “Beginner” 

This button highlights hardworking students based on specified conditions.

### 6. Quit
**Button**: Quit  
**Function**: Exits the application

## How to Use

1. **Load and Clean Data**: Use the "Load and Clean Data" button to import CSV data using the `clean_data()` function.

2. **Diplay Test Results**: Click "Diplay Test Results" button, enter a student ID, click "Submit" and the system will display the results using `test_result()`.

3. **Student Performance**: Click "Student Performance" button, input student ID and test name, then click "Submit" to see detailed performance metrics.

4. **Underperforming Students**: Click "Underperforming Students" to identify students who are not meeting performance criteria.

5. **Hardworking Students**: Click "Hardworking Students" to find students exceeding performance expectations.

6. **Quit**: Click "Quit" to exit the application.

## Important Instructions

1. Ensure SQLite is installed for database functions.
2. Use Jupyter Notebook with Python 3.x for the best experience.
3. Review function documentation within Jupyter for detailed instructions.
4. Input correct research IDs or test numbers for accurate data retrieval.
5. Handle data carefully and ensure backups are available.

This system aims to provide valuable insights into student performance and engagement, enabling Module Leaders to make informed decisions. Refer to the function descriptions in the code or contact the developer (F315284) for further assistance or improvements.

This README file serves as a comprehensive guide to using the Student Monitoring System. If you encounter any issues or have suggestions for improvement, please reach out to the developer (F315284).
